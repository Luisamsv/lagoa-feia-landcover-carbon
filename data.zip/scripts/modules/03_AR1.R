# Etapa 18D: teste exploratorio de tendencia da variancia movel sob nulo AR(1).
# Ler o arquivo auditado; nao altera os resultados das etapas anteriores.
# Requer apenas o R base. Execute com source() no seu computador.

pasta <- cfg$saida
clima <- ler(cfg$clima)
clima$meses_validos <- ifelse(clima$completo,12L,0L)
clima$precipitacao_anual_mm <- clima$P_mm
clima$pet_mm <- clima$PET_mm
clima <- clima[clima$meses_validos == 12 &
                 is.finite(clima$precipitacao_anual_mm) &
                 is.finite(clima$pet_mm) & is.finite(clima$AI), ]
clima <- clima[order(clima$ano_hid), ]
stopifnot(nrow(clima) == 37L,
          !anyDuplicated(clima$ano_hid),
          identical(as.integer(setdiff(1985:2024, clima$ano_hid)),
                    c(2012L, 2014L, 2023L)),
          abs(mean(clima$precipitacao_anual_mm) - 898.0919) < 0.01,
          all(abs(clima$AI - clima$precipitacao_anual_mm / clima$pet_mm) < 1e-5))

anos <- clima$ano_hid
proporcoes <- c(0.30, 0.40, 0.50)
B <- 1999L
set.seed(180240)

# Kendall tau da variancia movel dos residuos de tendencia linear.
# A largura e numero de observacoes validas, e nao numero fixo de anos.
tau_variancia <- function(ano, valor, largura) {
  stopifnot(length(ano) == length(valor), length(valor) >= largura)
  residuos <- residuals(lm(valor ~ ano))
  janelas <- seq.int(largura, length(valor))
  rv <- vapply(janelas, function(i) {
    stats::var(residuos[(i - largura + 1L):i])
  }, numeric(1))
  unname(stats::cor(seq_along(rv), rv, method = "kendall"))
}

analisar <- function(nome, valor) {
  n <- length(valor)
  modelo_media <- lm(valor ~ anos)
  residuos <- residuals(modelo_media)

  # Estima a autocorrelacao anual com NA nos 3 anos ausentes.
  residuo_calendario <- rep(NA_real_, length(1985:2024))
  residuo_calendario[match(anos, 1985:2024)] <- residuos
  ajuste_ar1 <- tryCatch(
    stats::arima(residuo_calendario, order = c(1, 0, 0),
                 include.mean = FALSE, method = "ML"),
    error = function(e) stop("Falha no ajuste AR(1) de ", nome, ": ", e$message)
  )
  phi <- unname(ajuste_ar1$coef["ar1"])
  sigma <- sqrt(ajuste_ar1$sigma2)
  if (!is.finite(phi) || abs(phi) >= 1 || !is.finite(sigma) || sigma <= 0) {
    stop("Modelo AR(1) nao estacionario ou invalido para ", nome)
  }
  predito <- fitted(modelo_media)

  # Cada serie substituta tem 40 anos; aplica-se a mesma mascara de 37 anos,
  # a mesma retirada de tendencia e as mesmas janelas aos dados observados.
  substitutas <- matrix(NA_real_, nrow = B, ncol = length(proporcoes))
  for (b in seq_len(B)) {
    ruido_40 <- as.numeric(stats::arima.sim(
      model = list(ar = phi), n = 40L, sd = sigma, n.start = 200L
    ))
    valor_sim <- predito + ruido_40[match(anos, 1985:2024)]
    for (j in seq_along(proporcoes)) {
      largura <- ceiling(proporcoes[j] * n)
      substitutas[b, j] <- tau_variancia(anos, valor_sim, largura)
    }
  }

  linhas <- vector("list", length(proporcoes))
  for (j in seq_along(proporcoes)) {
    largura <- ceiling(proporcoes[j] * n)
    observado <- tau_variancia(anos, valor, largura)
    # Probabilidade unilateral sob AR(1) estacionario; +1 evita p igual a zero.
    p_sim <- (1 + sum(substitutas[, j] >= observado)) / (B + 1)
    extensoes <- vapply(seq.int(largura, n), function(i) {
      anos[i] - anos[i - largura + 1L] + 1L
    }, integer(1))

    # Retira os dois anos de maior desvio absoluto, um de cada vez.
    anos_extremos <- anos[order(abs(residuos), decreasing = TRUE)[1:2]]
    tau_sem_extremo <- vapply(anos_extremos, function(ano_excluido) {
      manter <- anos != ano_excluido
      tau_variancia(anos[manter], valor[manter], largura)
    }, numeric(1))
    linhas[[j]] <- data.frame(
      Variavel = nome,
      Proporcao_janela = proporcoes[j],
      Janela_observacoes = largura,
      Extensao_anos_min = min(extensoes),
      Extensao_anos_max = max(extensoes),
      AR1_phi = phi,
      Tau_observado = observado,
      Tau_nulo_percentil95 = unname(stats::quantile(substitutas[, j], 0.95)),
      P_simulado_unilateral = p_sim,
      Ano_extremo_1 = anos_extremos[1],
      Tau_sem_extremo_1 = tau_sem_extremo[1],
      Ano_extremo_2 = anos_extremos[2],
      Tau_sem_extremo_2 = tau_sem_extremo[2]
    )
  }
  do.call(rbind, linhas)
}

resultado <- rbind(
  analisar("Precipitation", clima$precipitacao_anual_mm),
  analisar("Aridity index", clima$AI)
)
print(resultado, row.names = FALSE, digits = 5)
write.csv(resultado, file.path(pasta, "hydroclimate_ar1_simulations.csv"),
          row.names = FALSE)
cat("\nO p simulado avalia apenas o nulo AR(1) estacionario. Mesmo um resultado\n",
    "incomum sob esse nulo nao demonstra critical slowing down ou tipping point.\n")
