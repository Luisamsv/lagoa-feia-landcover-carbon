etapa_mapas <- function(cfg, p, serie) {
  dir.create(file.path(cfg$saida,"rasters"),recursive=TRUE,showWarnings=FALSE)
  dir.create(file.path(cfg$saida,"temporary"),showWarnings=FALSE)
  terra::terraOptions(memfrac=0.15,memmax=1,tempdir=file.path(cfg$saida,"temporary"),todisk=TRUE)
  opt <- list(datatype="FLT8S",gdal=c("COMPRESS=LZW","BIGTIFF=IF_SAFER"))
  caminho <- function(nome) file.path(cfg$saida,"rasters",paste0(nome,".tif"))
  reutilizar <- function(f) cfg$retomar && file.exists(f)
  gravar <- function(r,f) {if(reutilizar(f)) terra::rast(f) else terra::writeRaster(r,f,overwrite=FALSE,wopt=opt)}
  zsum <- function(x,z) {
    v <- terra::zonal(x,z,fun="sum",na.rm=TRUE)
    names(v)[1:2] <- c("codigo","valor");v
  }
  soma <- function(r) as.numeric(terra::global(r,"sum",na.rm=TRUE)[1,1])
  mapas <- vapply(cfg$anos,function(ano) {
    f <- file.path(cfg$mapas,paste0("proj_uso_clipado_",ano,"_corrigido.tif"))
    precisa(f);f
  },character(1))
  molde <- terra::rast(mapas[1]);bacia <- terra::vect(cfg$bacia)
  if (!nzchar(terra::crs(molde)) || !nzchar(terra::crs(bacia))) stop("CRS ausente.")
  bacia <- terra::project(bacia,terra::crs(molde))
  a_arq <- file.path(cfg$auditoria,"historical_code_areas.csv")
  precisa(a_arq);a_audit <- ler(a_arq);campos(a_audit,c("ano","lucode","area_ha"))
  areas <- list();estoques <- list();conf <- list();limpos <- character(length(cfg$anos))
  for(i in seq_along(cfg$anos)) {
    ano <- cfg$anos[i];cat("\nMapa e estoque:",ano,"\n")
    r <- terra::rast(mapas[i])
    if(terra::nlyr(r)!=1 || !isTRUE(terra::compareGeom(molde,r,stopOnError=FALSE))) stop("Geometria diferente: ",mapas[i])
    f <- caminho(paste0("masked_original_landcover_",ano))
    if(reutilizar(f)) r <- terra::rast(f) else {
      r <- terra::mask(r,bacia,touches=FALSE,filename=tempfile(tmpdir=file.path(cfg$saida,"temporary"),fileext=".tif"))
      r <- terra::classify(r,cbind(0,NA_real_),filename=f,overwrite=FALSE)
    }
    limpos[i] <- f
    if(i==1) {
      area_f <- caminho("cell_area_ha")
      if(reutilizar(area_f)) ar <- terra::rast(area_f) else ar <- terra::cellSize(r,unit="ha",mask=TRUE,filename=area_f,wopt=opt)
      valido <- !is.na(r)
    }
    n <- as.numeric(terra::global(r,"notNA")[1,1])
    if(n!=cfg$celulas_esperadas) stop("Numero de celulas diferente em ",ano,": ",n)
    diferentes <- soma((!is.na(r))!=valido)
    if(diferentes!=0) stop("Suporte classificado diferente em ",ano)
    az <- zsum(ar,r);az$ano <- ano;names(az)[1:2] <- c("lucode","area_ha")
    if(any(!az$lucode %in% p$lucode)) stop("Codigo sem parametro em ",ano)
    esp <- a_audit[a_audit$ano==ano,c("lucode","area_ha")]
    ck <- merge(az,esp,by="lucode",all=TRUE,suffixes=c("_mapa","_audit"))
    ck$area_ha_mapa[is.na(ck$area_ha_mapa)] <- 0;ck$area_ha_audit[is.na(ck$area_ha_audit)] <- 0
    if(any(abs(ck$area_ha_mapa-ck$area_ha_audit)>cfg$tolerancia_area_ha)) stop("Area por codigo nao reproduz auditoria: ",ano)
    at <- sum(az$area_ha)
    if(abs(at-cfg$area_esperada)>cfg$tolerancia_area_ha) stop("Area total diferente.")
    az$classe_real <- p$classe_real[match(az$lucode,p$lucode)]
    az$classe_estudo <- p$classe_estudo[match(az$lucode,p$lucode)]
    az$C_total <- p$C_total[match(az$lucode,p$lucode)]
    az$carbono_total_Tg <- az$area_ha*az$C_total/1e6
    dfile <- caminho(paste0("carbon_density_Mg_ha_",ano))
    if(reutilizar(dfile)) d <- terra::rast(dfile) else d <- terra::classify(r,as.matrix(p[c("lucode","C_total")]),others=NA,filename=dfile,wopt=opt)
    st <- gravar(d*ar,caminho(paste0("carbon_stock_Mg_cell_",ano)))
    total <- soma(st)/1e6; esperado <- serie$carbono_total_Tg[match(ano,serie$ano)]
    if(abs(total-esperado)>cfg$tolerancia_carbono_Tg) stop("Estoque raster nao fecha com referencia em ",ano)
    if(cfg$criar_quatro_pools) {
      pool_sum <- 0
      for(pool in c("C_above","C_below","C_soil","C_dead")) {
        df <- tempfile(tmpdir=file.path(cfg$saida,"temporary"),fileext=".tif")
        den <- terra::classify(r,as.matrix(p[c("lucode",pool)]),others=NA,filename=df,wopt=opt)
        pr <- gravar(den*ar,caminho(paste0(pool,"_Mg_cell_",ano)))
        pool_sum <- pool_sum+soma(pr)/1e6;rm(pr,den);unlink(df)
      }
      if(abs(pool_sum-total)>cfg$tolerancia_carbono_Tg) stop("Quatro pools nao fecham: ",ano)
    }
    areas[[i]] <- az
    conf[[i]] <- data.frame(ano=ano,celulas=n,area_ha=at,estoque_raster_Tg=total,estoque_serie_Tg=esperado,diferenca_Tg=total-esperado)
    gc()
  }
  pc <- do.call(rbind,areas);salvar(pc,"historical_area_carbon_by_code.csv",cfg)
  agr <- aggregate(cbind(area_ha,carbono_total_Tg)~ano+classe_estudo,pc,sum)
  agr$densidade_media_Mg_ha <- agr$carbono_total_Tg*1e6/agr$area_ha
  salvar(agr,"historical_carbon_by_class.csv",cfg)
  conferir <- do.call(rbind,conf);salvar(conferir,"raster_stock_checks.csv",cfg)
  # Origem*100+destino: codigos originais inteiros menores que 100.
  if(any(p$lucode>=100)||any(p$lucode!=floor(p$lucode))) stop("Codigos incompativeis com a chave de transicao.")
  pares <- rbind(data.frame(inicio=head(cfg$anos,-1),fim=tail(cfg$anos,-1)),data.frame(inicio=1985,fim=2024))
  bal <- list();nativos <- c(3,11,12,49,50)
  for(k in seq_len(nrow(pares))) {
    y0 <- pares$inicio[k];y1 <- pares$fim[k];cat("\nTransicoes:",y0,"->",y1,"\n")
    r0 <- terra::rast(limpos[match(y0,cfg$anos)]);r1 <- terra::rast(limpos[match(y1,cfg$anos)])
    keyfile <- tempfile(tmpdir=file.path(cfg$saida,"temporary"),fileext=".tif")
    key <- terra::writeRaster(r0*100+r1,keyfile,overwrite=FALSE,datatype="INT4S",gdal="COMPRESS=LZW")
    tab <- zsum(ar,key);tab$codigo_inicial <- tab$codigo%/%100;tab$codigo_final <- tab$codigo%%100
    tab$area_ha <- tab$valor;tab$codigo <- tab$valor <- NULL
    i0 <- match(tab$codigo_inicial,p$lucode);i1 <- match(tab$codigo_final,p$lucode)
    tab$classe_inicial <- p$classe_real[i0];tab$classe_final <- p$classe_real[i1]
    tab$grupo_inicial <- p$classe_estudo[i0];tab$grupo_final <- p$classe_estudo[i1]
    tab$densidade_inicial_Mg_ha <- p$C_total[i0];tab$densidade_final_Mg_ha <- p$C_total[i1]
    tab$delta_densidade_Mg_ha <- tab$densidade_final_Mg_ha-tab$densidade_inicial_Mg_ha
    tab$delta_carbono_Tg <- tab$area_ha*tab$delta_densidade_Mg_ha/1e6
    c0 <- sum(tab$area_ha*tab$densidade_inicial_Mg_ha)/1e6;c1 <- sum(tab$area_ha*tab$densidade_final_Mg_ha)/1e6
    esp <- serie$carbono_total_Tg[match(c(y0,y1),serie$ano)]
    if(any(abs(c(c0,c1)-esp)>cfg$tolerancia_carbono_Tg)||abs(sum(tab$area_ha)-cfg$area_esperada)>cfg$tolerancia_area_ha) stop("Transicoes nao fecham: ",y0,"-",y1)
    nome <- paste0(y0,"_",y1)
    salvar(tab[order(-abs(tab$delta_carbono_Tg)),],paste0("original_code_transitions_",nome,".csv"),cfg)
    ag <- aggregate(cbind(area_ha,delta_carbono_Tg)~grupo_inicial+grupo_final,tab,sum)
    salvar(ag[order(-abs(ag$delta_carbono_Tg)),],paste0("study_class_transitions_",nome,".csv"),cfg)
    mudou <- tab[tab$codigo_inicial!=tab$codigo_final,]
    mudou <- mudou[order(-abs(mudou$delta_carbono_Tg)),]
    if(y0==2010 && y1==2015) salvar(mudou,"changed_code_transitions_2010_2015.csv",cfg)
    if(y0==1985 && y1==2024) salvar(mudou,"endpoint_changed_code_transitions.csv",cfg)
    perda <- sum(tab$area_ha[tab$codigo_inicial %in% nativos & !(tab$codigo_final %in% nativos)])
    ganho <- sum(tab$area_ha[!(tab$codigo_inicial %in% nativos) & tab$codigo_final %in% nativos])
    bal[[k]] <- data.frame(ano_inicial=y0,ano_final=y1,periodo=paste(y0,y1,sep="-"),perda_nativa_ha=perda,ganho_nativo_ha=ganho,estoque_inicial_Tg=c0,estoque_final_Tg=c1,delta_Tg=c1-c0,delta_pct=100*(c1-c0)/c0,ganhos_brutos_Tg=sum(tab$delta_carbono_Tg[tab$delta_carbono_Tg>0]),perdas_brutas_Tg=sum(tab$delta_carbono_Tg[tab$delta_carbono_Tg<0]))
    d0 <- terra::rast(caminho(paste0("carbon_density_Mg_ha_",y0)));d1 <- terra::rast(caminho(paste0("carbon_density_Mg_ha_",y1)))
    dd <- gravar(d1-d0,caminho(paste0("carbon_density_change_Mg_ha_",nome)))
    ds <- gravar(dd*ar,caminho(paste0("carbon_stock_change_Mg_cell_",nome)))
    if(abs(soma(ds)/1e6-(c1-c0))>cfg$tolerancia_carbono_Tg) stop("Mapa delta nao fecha: ",nome)
    rm(key,ds,dd);unlink(keyfile);gc()
  }
  b <- do.call(rbind,bal);salvar(b,"interval_carbon_balance.csv",cfg)
  print(conferir,row.names=FALSE,digits=9)
  list(por_codigo=pc,por_classe=agr,balanco=b)
}
