# Historical ONI ERSSTv5; overlapping three-month seasons, not monthly anomalies.
# Recovered tables1.R rules, now reading an archived CSV instead of the clipboard.
run_enso <- function(cfg) {
  x <- ler(file.path(cfg$referencia,'oni_seasonal_1984_2024.csv'))
  seasons <- c('DJF','JFM','FMA','MAM','AMJ','MJJ','JJA','JAS','ASO','SON','OND','NDJ')
  campos(x,c('year','season','oni_degC'))
  if(nrow(x)!=492L || anyDuplicated(x[c('year','season')]) ||
     !is.numeric(x$oni_degC)||any(!is.finite(x$oni_degC)) ||
     !setequal(x$year,1984:2024)||any(!x$season %in% seasons))stop('Invalid archived ONI input.')
  x <- x[order(x$year,match(x$season,seasons)),]
  x$phase <- ifelse(x$oni_degC>=.5,'El Niño',ifelse(x$oni_degC<=-.5,'La Niña','Neutral'))
  x$group <- cumsum(c(TRUE,head(x$phase,-1)!=tail(x$phase,-1)))
  rows <- lapply(split(x,x$group),function(g) {
    if(g$phase[1]=='Neutral'||nrow(g)<5L)return(NULL)
    peak <- which.max(abs(g$oni_degC));value <- g$oni_degC[peak]
    data.frame(first_season=paste(g$season[1],g$year[1]),
      last_season=paste(tail(g$season,1),tail(g$year,1)),ENSO_phase=g$phase[1],
      intensity=as.character(cut(abs(value),breaks=c(.5,1,1.5,2,Inf),
        labels=c('Weak','Moderate','Strong','Very strong'),right=FALSE)),
      peak_ONI_degC=value,peak_season=paste(g$season[peak],g$year[peak]),
      start_year=g$year[1],end_year=tail(g$year,1))
  })
  episodes <- do.call(rbind,rows)
  episodes <- episodes[episodes$end_year>=1985 & episodes$start_year<=2024,1:6]
  ref <- ler(file.path(cfg$referencia,'enso_episodes_reference.csv'))
  if(nrow(episodes)!=nrow(ref))stop('ENSO episode count differs from reference.')
  if(any(as.matrix(episodes[c(1:4,6)])!=as.matrix(ref[c(1:4,6)]))||
     any(abs(episodes[[5]]-ref[[5]])>1e-8))stop('ENSO episode reference mismatch.')
  salvar(episodes,'enso_episodes.csv',cfg)
  invisible(episodes)
}
