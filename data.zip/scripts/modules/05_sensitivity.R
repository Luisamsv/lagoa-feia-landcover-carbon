run_sensitivity <- function(cfg,p,a) {
  pools <- c("C_above","C_below","C_soil","C_dead")
  codigos <- p$lucode
  # Sensibilidade conjunta: alternativas descritivas, nunca IC ou probabilidades.
  floresta <- rbind(c(94.28,19.38,187,14.62),c(113.21,22.54,234,14.39),c(126.72,28.28,281,21.77))
  grade <- expand.grid(floresta=1:3,solo_wetland=c(219,283,347),
    peso_pastagem_mosaico=c(0,.5,1),solo_pastagem=c(99.88,109.86,142.33),
    solo_restinga=c(4.89,23.20,43.79),fator_urbano=c(.5,1,1.5),
    fator_biomassa_wetland=c(.5,1,1.5))
  recompor <- function(z,w=.5) {
    z[z$lucode==21,pools] <- w*z[z$lucode==15,pools]+(1-w)*z[z$lucode==41,pools];z
  }
  ar0 <- a$area_ha[a$ano==1985][match(p$lucode,a$lucode[a$ano==1985])]
  ar1 <- a$area_ha[a$ano==2024][match(p$lucode,a$lucode[a$ano==2024])]
  ar0[is.na(ar0)] <- 0;ar1[is.na(ar1)] <- 0 # codigos ausentes na tabela de areas = area zero
  extremos <- function(z) {
    d <- rowSums(z[pools]);v0 <- sum(ar0*d)/1e6;v1 <- sum(ar1*d)/1e6
    c(estoque_1985_Tg=v0,estoque_2024_Tg=v1,ganho_Tg=v1-v0,ganho_pct=100*(v1-v0)/v0)
  }
  sens <- vector("list",nrow(grade))
  for (i in seq_len(nrow(grade))) {
    z <- p;g <- grade[i,]
    z[z$lucode==3,pools] <- as.list(floresta[g$floresta,])
    z$C_soil[z$lucode==11] <- g$solo_wetland
    z$C_soil[z$lucode %in% c(12,15)] <- g$solo_pastagem
    z$C_soil[z$lucode %in% c(49,50)] <- g$solo_restinga
    z[z$lucode==24,pools] <- z[z$lucode==24,pools]*g$fator_urbano
    ps <- c("C_above","C_below","C_dead")
    z[z$lucode==11,ps] <- z[z$lucode==11,ps]*g$fator_biomassa_wetland
    z <- recompor(z,g$peso_pastagem_mosaico)
    sens[[i]] <- cbind(id=i,g,as.data.frame(as.list(extremos(z))))
  }
  sens <- do.call(rbind,sens)
  # Estresse isolado por classe, incluindo fontes que a grade nao varia.
  estresse <- list();k <- 0L
  add_stress <- function(z,label,code,factor) {
    data.frame(hipotese=label,lucode=code,fator=factor,t(extremos(z)),check.names=FALSE)
  }
  for (code in setdiff(codigos,33)) for (f in c(.75,1.25)) {
    z <- p;z[z$lucode==code,pools] <- z[z$lucode==code,pools]*f
    if (code %in% c(15,41)) z <- recompor(z)
    k <- k+1L;estresse[[k]] <- add_stress(z,"Densidade da classe +/-25%; mosaico ligado aos componentes",code,f)
  }
  z <- p;z$C_below[z$lucode==11] <- 0
  k <- k+1L;estresse[[k]] <- add_stress(z,"Wetland: BGB separado excluido para testar sobreposicao potencial com SOC",11,NA_real_)
  for (v in c(24.9,37.5)) {
    z <- p;z$C_soil[z$lucode==31] <- v;k <- k+1L
    estresse[[k]] <- add_stress(z,paste("Aquaculture: SOC de tanque individual",v),31,NA_real_)
  }
  for (v in c(4.89,23.20,43.79)) {
    z <- p;z$C_soil[z$lucode %in% c(23,25)] <- v;k <- k+1L
    estresse[[k]] <- add_stress(z,paste("Superficies sem vegetacao: SOC arenoso assumido",v),23,NA_real_)
  }
  for (r in c(.2,.4)) {
    z <- p;z$C_below[z$lucode==49] <- z$C_above[z$lucode==49]*r;k <- k+1L
    estresse[[k]] <- add_stress(z,paste("Restinga arborea: razao raiz/parte aerea assumida",r),49,NA_real_)
  }
  estresse <- do.call(rbind,estresse)

  salvar(sens,"joint_parameter_sensitivity.csv",cfg)
  salvar(estresse,"isolated_parameter_stress_tests.csv",cfg)
  invisible(list(joint=sens,isolated=estresse))
}
