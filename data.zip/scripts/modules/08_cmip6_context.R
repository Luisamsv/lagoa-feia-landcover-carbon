# Descriptive station/model contrasts; not bias-corrected climate anomalies.
# Reproduces numerical summaries from deposited basin-extracted CMIP6 data.
run_cmip6 <- function(cfg) {
  x <- ler(file.path(cfg$referencia,'cmip6_basin_precipitation.csv'))
  campos(x,c('model','scenario','period','start_year','end_year',
             'precipitation_basin_mm','precipitation_single_pixel_mm',
             'extraction_area_ha','intersecting_cells'))
  scenarios <- c('SSP1-2.6','SSP2-4.5','SSP3-7.0','SSP5-8.5')
  periods <- c('2021-2040','2041-2060','2061-2080')
  if(nrow(x)!=12L||anyDuplicated(x[c('scenario','period')])||
     !setequal(x$scenario,scenarios)||!setequal(x$period,periods)||
     any(x$model!='MRI-ESM2-0')||any(!is.finite(x$precipitation_basin_mm))||
     any(x$precipitation_basin_mm<=0))stop('Invalid CMIP6 scenario/period input.')
  if(any(paste(x$start_year,x$end_year,sep='-')!=x$period))stop('CMIP6 period/year mismatch.')
  for(period in periods)if(!setequal(x$scenario[x$period==period],scenarios))stop('Incomplete scenario set.')
  h <- ler(cfg$clima)
  mu <- mean(h$P_mm[h$completo])
  if(!is.finite(mu)||abs(mu-898.0919)>.01)stop('Station reference differs from audited mean.')
  # Never reuse the supplied FINAL file's obsolete anomaly baseline of 1335.99 mm.
  x$station_reference_mm <- mu
  x$descriptive_difference_mm <- x$precipitation_basin_mm-mu
  x$descriptive_difference_pct <- 100*x$descriptive_difference_mm/mu
  x$comparison_scope <- 'Different spatial support; historical model bias not evaluated'
  summary <- do.call(rbind,lapply(periods,function(period) {
    z <- x[x$period==period,]
    data.frame(period=period,precipitation_min_mm=min(z$precipitation_basin_mm),
      precipitation_max_mm=max(z$precipitation_basin_mm),
      precipitation_scenario_mean_mm=mean(z$precipitation_basin_mm),
      station_reference_mm=mu,
      descriptive_difference_min_pct=min(z$descriptive_difference_pct),
      descriptive_difference_max_pct=max(z$descriptive_difference_pct))
  }))
  ref <- ler(file.path(cfg$referencia,'cmip6_period_summary_reference.csv'))
  j <- match(summary$period,ref$period)
  if(anyNA(j)||anyDuplicated(ref$period)||nrow(ref)!=3L)stop('Invalid CMIP6 summary reference.')
  cols <- setdiff(names(summary),'period')
  if(any(abs(as.matrix(summary[cols])-as.matrix(ref[j,cols]))>1e-8))
    stop('CMIP6 summary reference mismatch.')
  # Historical periods used in Figure 5, distinct from Table 2 intervals.
  starts <- c(1985,1990,2000,2010,2020);ends <- c(1989,1999,2009,2019,2024)
  historical <- do.call(rbind,lapply(seq_along(starts),function(i) {
    z <- h[h$completo & h$ano_hid>=starts[i] & h$ano_hid<=ends[i],]
    if(!nrow(z))stop('Empty historical context period.')
    data.frame(period=paste(starts[i],ends[i],sep='-'),
      n_complete_years=nrow(z),precipitation_station_mean_mm=mean(z$P_mm),
      included_hydrological_years=paste(z$ano_hid,collapse=';'))
  }))
  salvar(x,'cmip6_station_descriptive_comparison.csv',cfg)
  salvar(summary,'cmip6_period_summary.csv',cfg)
  salvar(historical,'historical_precipitation_period_means.csv',cfg)
  invisible(list(scenarios=x,summary=summary,historical=historical))
}
