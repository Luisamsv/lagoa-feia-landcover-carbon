# Analises exploratorias: p nominais nao tratam autocorrelacao/janelas sobrepostas.
etapa_estatisticas <- function(cfg, serie, balanco) {
  status <- character();clima <- NULL
  escolher <- function(x,opcoes) {z<-intersect(opcoes,names(x));if(length(z))z[1] else NA_character_}
  if(file.exists(cfg$clima)) {
    h <- ler(cfg$clima)
    # Adapter only: the supplied CSV already contains the audited hydrological series.
    if (all(c("P_mm","PET_mm","AI","completo") %in% names(h))) {
      h$precipitacao_anual_mm <- h$P_mm
      h$meses_validos <- ifelse(h$completo,12L,0L)
    }
    cy <- escolher(h,c("ano_hid"));cp <- escolher(h,c("precipitacao_anual_mm","prec_mm"));cm <- escolher(h,c("meses_validos","meses_completos"))
    ct <- escolher(h,c("pet_mm","PET_mm","pet_anual_mm","PET_anual_mm","PET","pet","PET_TerraClimate_mm"))
    ca <- escolher(h,c("AI","AI_hidrologico","AI_anual","aridity_index"))
    if(anyNA(c(cy,cp,cm))) status <- c(status,paste("CLIMA: colunas nao reconhecidas. Disponiveis:",paste(names(h),collapse=", "))) else {
      if(anyDuplicated(h[[cy]])) stop("Ano hidrologico duplicado no CSV auditado.")
      clima <- data.frame(ano_hid=h[[cy]],P_mm=h[[cp]],completo=!is.na(h[[cm]]) & h[[cm]]==12 & is.finite(h[[cp]]))
      clima$PET_mm <- if(!is.na(ct)) h[[ct]] else NA_real_
      # PET externa so pode ser associada quando ja tem ano_hid explicito.
      if(is.na(ct) && file.exists(cfg$pet)) {
        pt <- ler(cfg$pet);ptc <- escolher(pt,c("pet_mm","PET_mm","pet_anual_mm","PET_anual_mm","PET","pet","pet_total_mm"))
        if("ano_hid" %in% names(pt) && !is.na(ptc) && !anyDuplicated(pt$ano_hid)) clima$PET_mm <- pt[[ptc]][match(clima$ano_hid,pt$ano_hid)] else status<-c(status,"PET externa sem ano_hid/coluna reconhecida: nao associada automaticamente a anos hidrologicos.")
      }
      clima$AI <- if(!is.na(ca)) h[[ca]] else ifelse(is.finite(clima$PET_mm)&clima$PET_mm>0,clima$P_mm/clima$PET_mm,NA_real_)
      clima$P_mm[!clima$completo] <- NA_real_;clima$AI[!clima$completo] <- NA_real_
      salvar(clima,"hydrological_climate.csv",cfg)
    }
  } else status<-c(status,"CSV de clima auditado ausente: Table2 com clima e correlacoes pendentes.")
  tab2 <- balanco[balanco$ano_final-balanco$ano_inicial<39,]
  tab2$n_anos_clima <- 0L;tab2$precipitacao_media_mm <- tab2$PET_media_mm <- tab2$AI_medio <- NA_real_
  for(i in seq_len(nrow(tab2))) if(!is.null(clima)) {
    z <- clima[clima$ano_hid>=tab2$ano_inicial[i] & clima$ano_hid<tab2$ano_final[i] & clima$completo,]
    media <- function(v) if(any(is.finite(v)))mean(v[is.finite(v)]) else NA_real_
    tab2$n_anos_clima[i] <- sum(is.finite(z$P_mm))
    tab2$precipitacao_media_mm[i] <- media(z$P_mm);tab2$PET_media_mm[i] <- media(z$PET_mm);tab2$AI_medio[i] <- media(z$AI)
  }
  salvar(tab2,"interval_climate_carbon.csv",cfg)
  correlacoes <- list();k<-0L
  for(x in c("precipitacao_media_mm","PET_media_mm","AI_medio")) for(y in c("delta_Tg","delta_pct")) for(m in c("pearson","spearman")) {
    ok <- is.finite(tab2[[x]]) & is.finite(tab2[[y]]);n<-sum(ok)
    rr<-pp<-NA_real_
    if(n>=3 && stats::sd(tab2[[x]][ok])>0 && stats::sd(tab2[[y]][ok])>0) {
      tst<-suppressWarnings(stats::cor.test(tab2[[x]][ok],tab2[[y]][ok],method=m,exact=FALSE));rr<-unname(tst$estimate);pp<-tst$p.value
    }
    k<-k+1L;correlacoes[[k]]<-data.frame(preditor=x,resposta=y,metodo=m,n=n,coeficiente=rr,p_nominal=pp)
  }
  corrs<-do.call(rbind,correlacoes)
  corrs$p_Holm_familia_12<-p.adjust(corrs$p_nominal,method="holm",n=12)
  salvar(corrs,"climate_carbon_correlations.csv",cfg)
  # Pearson/Spearman x Delta absoluto/percentual sao 12 testes explicitamente novos.
  # Nao substituir automaticamente familias antigas que tinham outras hipoteses.
  ews <- list();rolling <- list();j<-0L
  entradas <- list(Carbon_stock=list(x=serie$carbono_total_Tg,anos=serie$ano),Delta_carbon=list(x=diff(serie$carbono_total_Tg),anos=tail(serie$ano,-1)))
  for(nm in names(entradas)) {
    x<-entradas[[nm]]$x;tt<-entradas[[nm]]$anos
    res<-residuals(lm(x~tt))
    for(fr in c(.3,.4,.5)) {
      w<-ceiling(length(x)*fr);ends<-seq.int(w,length(x))
      va<-vapply(ends,function(e)var(res[seq.int(e-w+1,e)]),numeric(1))
      tau<-pv<-NA_real_
      if(length(va)>=3 && sd(va)>0) {
        tst<-suppressWarnings(cor.test(tt[ends],va,method="kendall",exact=FALSE));tau<-unname(tst$estimate);pv<-tst$p.value
      }
      j<-j+1L
      ews[[j]]<-data.frame(variable=nm,window_fraction=fr,window_n=w,n_rolling=length(va),tau=tau,p_naive_two_sided=pv,window_years_min=min(tt[ends]-tt[ends-w+1]+1),window_years_max=max(tt[ends]-tt[ends-w+1]+1))
      rolling[[j]]<-data.frame(variable=nm,window_fraction=fr,window_n=w,ano_final=tt[ends],rolling_variance=va)
    }
  }
  ew<-do.call(rbind,ews);ew$p_Holm_6<-p.adjust(ew$p_naive_two_sided,"holm")
  salvar(ew,"carbon_rolling_variance_statistics.csv",cfg)
  salvar(do.call(rbind,rolling),"carbon_rolling_variance.csv",cfg)
  # Preserva estatisticas hidroclimaticas do teste AR(1) auditado, em colunas distintas.
  hf<-file.path(cfg$pasta,"hydroclimate_ar1_simulations.csv")
  if(file.exists(hf)) {
    hy<-ler(hf)
    req<-c("Variavel","Proporcao_janela","Janela_observacoes","Tau_observado","P_simulado_unilateral")
    if(all(req %in% names(hy))) {
      hy<-hy[hy$Variavel %in% c("Precipitation","Aridity index"),]
      hh<-data.frame(variable=hy$Variavel,window_fraction=hy$Proporcao_janela,window_n=hy$Janela_observacoes,tau=hy$Tau_observado,p_stationary_AR1_one_sided=hy$P_simulado_unilateral,p_naive_Kendall_two_sided=NA_real_,test="Stationary AR1 simulation (audited, unchanged)")
      ec<-data.frame(variable=ew$variable,window_fraction=ew$window_fraction,window_n=ew$window_n,tau=ew$tau,p_stationary_AR1_one_sided=NA_real_,p_naive_Kendall_two_sided=ew$p_naive_two_sided,test="Naive Kendall, short irregular carbon series")
      salvar(rbind(hh,ec),"hydroclimate_carbon_variance_tests.csv",cfg)
      file.copy(hf,file.path(cfg$saida,"hydroclimate_ar1_reference.csv"),overwrite=TRUE)
    } else status<-c(status,"TableS2 combinada nao gerada: colunas do CSV AR1 auditado nao reconhecidas. Linhas de carbono foram geradas separadamente.")
  } else status<-c(status,"TableS2 combinada nao gerada: CSV hydroclimate_ar1_simulations.csv ausente. Linhas de carbono geradas separadamente.")

  writeLines(c(status,
    "EWS: detrend linear contra ano real; janela=ceiling(n*fracao); variancia amostral; janela alinhada ao fim.",
    "DeltaC corresponde a diferencas entre estoques em datas irregulares, nao fluxo anual; nao dividido por duracao.",
    "Carbon stock: nove observacoes. DeltaC: oito intervalos. Numero de observacoes nao equivale a numero de anos.",
    "p de Kendall bilateral por cor.test(exact=FALSE): nao ajusta dependencia das janelas; nao replica automaticamente outros implementos de Mann-Kendall.",
    "EWS atualizado apenas para carbono; resultados hidroclimaticos AR(1) ja auditados nao foram modificados.",
    "Nao simulamos AR(1) do carbono: nove datas irregulares nao sustentam tratar cada passo como um ano.",
    "Correlacoes usam intervalos [ano inicial, ano final); anos sem 12 meses excluidos.",
    "Holm das 12 correlacoes e dos 6 testes EWS nao corrige dependencia temporal.",
    "Nao foi estimado efeito causal de clima no carbono ou resposta do carbono aos SSPs."),file.path(cfg$saida,"statistical_scope.txt"))
  cat("\n--- EWS CARBONO ATUALIZADO ---\n");print(ew,row.names=FALSE,digits=6)
  if(length(status))cat("\nPendencias de colunas/clima:\n",paste(status,collapse="\n"),"\n")
  list(table2=tab2,correlacoes=corrs,ews=ew,rolling=do.call(rbind,rolling),pendencias=status)
}
