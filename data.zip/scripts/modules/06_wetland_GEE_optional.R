# ETAPA 19 RECONSTRUIDA -- wetland natural (11) x clima hidrologico auditado.
# R >= 4.0; execute como arquivo completo, preferencialmente em sessao nova.
# Produto GEE recuperado do checkpoint de 23/09/2026.
# Os nove mapas locais nao comprovam a origem dos outros 31 anos:
# a verificacao abaixo confere distribuicoes e amostras nos nove anos disponiveis.
# As correlacoes continuam exploratorias; nao demonstram causalidade.

pasta <- cfg$saida
pasta_mapas <- cfg$mapas
arquivo_bacia <- cfg$bacia
arquivo_clima <- file.path(pasta, "hydrological_climate_original_schema.csv")
asset <- paste0("projects/mapbiomas-public/assets/brazil/lulc/collection10_1/",
                "mapbiomas_brazil_collection10_1_coverage_v1")
# Pode ficar vazio se houver projeto padrao nas credenciais do Earth Engine.
projeto_gee <- Sys.getenv("EARTHENGINE_PROJECT", unset = "")
anos_locais <- c(1985, 1990, 1995, 2000, 2005, 2010, 2015, 2020, 2024)

pacotes <- c("terra", "sf", "jsonlite", "reticulate")
faltam <- pacotes[!vapply(pacotes, requireNamespace, logical(1), quietly = TRUE)]
if (length(faltam)) stop("Instale os pacotes R: ", paste(faltam, collapse = ", "))
if (!dir.exists(pasta)) stop("Pasta de resultados ausente: ", pasta)
if (!file.exists(arquivo_bacia) || !file.exists(cfg$clima)) {
  stop("Bacia ou clima auditado ausente. Confira os caminhos no inicio.")
}

clima <- ler(cfg$clima)
clima$meses_validos <- ifelse(clima$completo,12L,0L)
clima$precipitacao_anual_mm <- clima$P_mm
clima$pet_mm <- clima$PET_mm
campos <- c("ano_hid", "meses_validos", "precipitacao_anual_mm", "pet_mm", "AI")
if (!all(campos %in% names(clima))) stop("Colunas ausentes no clima auditado.")
if (anyDuplicated(clima$ano_hid) || !setequal(clima$ano_hid, 1985:2024)) {
  stop("O clima deve conter os 40 anos unicos de 1985 a 2024.")
}
completos <- !is.na(clima$meses_validos) & clima$meses_validos == 12 &
  is.finite(clima$precipitacao_anual_mm) & is.finite(clima$pet_mm) & clima$pet_mm > 0
if (sum(completos) != 37L ||
    !setequal(clima$ano_hid[!completos], c(2012, 2014, 2023)) ||
    abs(mean(clima$precipitacao_anual_mm[completos]) - 898.0919) > 0.01) {
  stop("O clima nao corresponde a auditoria de 37 anos e media 898,1 mm.")
}
ai_calculado <- clima$precipitacao_anual_mm / clima$pet_mm
if (any(!is.finite(clima$AI[completos])) ||
    any(abs(clima$AI[completos] - ai_calculado[completos]) > 1e-6)) {
  stop("AI do arquivo difere de P/PET nos anos completos.")
}
clima$AI <- ifelse(completos, ai_calculado, NA_real_)
clima$precipitacao_anual_mm[!completos] <- NA_real_

# Grade, bacia e 19 celulas de borda sem classificacao da base local.
mapa <- function(ano) file.path(pasta_mapas,
                              paste0("proj_uso_clipado_", ano, "_corrigido.tif"))
if (any(!file.exists(vapply(anos_locais, mapa, character(1))))) {
  stop("Falta algum dos nove mapas originais locais.")
}
ref <- terra::rast(mapa(1985))
if (terra::nlyr(ref) != 1L) stop("Mapa de referencia deve ter uma camada.")
crs_sf <- sf::st_crs(terra::crs(ref))
if (is.na(crs_sf)) stop("CRS do mapa ausente.")
crs_gee <- if (!is.na(crs_sf$epsg)) paste0("EPSG:", crs_sf$epsg) else crs_sf$wkt
bacia <- sf::st_read(arquivo_bacia, quiet = TRUE)
bacia <- sf::st_make_valid(bacia)
bacia <- sf::st_sf(id = 1L, geometry = sf::st_union(bacia))
bacia_local <- terra::vect(sf::st_transform(bacia, crs_sf))
dentro <- terra::rasterize(bacia_local, ref, field = 1, touches = FALSE)
ref_mask <- terra::mask(ref, dentro)
ref_mask <- terra::ifel(ref_mask == 0, NA, ref_mask)
n_ref <- as.numeric(terra::global(!is.na(ref_mask), "sum", na.rm = TRUE)[1, 1])
area_ref <- as.numeric(terra::global(terra::cellSize(ref_mask, unit = "ha", mask = TRUE),
                                    "sum", na.rm = TRUE)[1, 1])
if (n_ref != 4183460 || abs(area_ref - 335809.5476) > 0.1) {
  stop("O mapa/bacia nao reproduz o suporte auditado: ", n_ref,
       " celulas; ", round(area_ref, 4), " ha.")
}
bad <- terra::ifel(!is.na(dentro) & is.na(ref_mask), 1, NA)
pts_bad <- terra::as.points(bad, values = FALSE)
xy_bad <- terra::crds(pts_bad)
resolucao <- terra::res(ref)
af <- c(resolucao[1], 0, terra::xmin(ref), 0, -resolucao[2], terra::ymax(ref))
excluir <- lapply(seq_len(nrow(xy_bad)), function(i) {
  c(floor((xy_bad[i, 1] - terra::xmin(ref)) / resolucao[1]),
    floor((terra::ymax(ref) - xy_bad[i, 2]) / resolucao[2]))
})
if (length(excluir) != 19L) stop("Esperadas 19 celulas sem classificacao na borda.")

# Envia o contorno das celulas efetivamente validas do raster auditado.
# Nao simplificar nem suavizar esta geometria: suas bordas acompanham a grade.
cat("\nConstruindo contorno do suporte raster auditado...\n")
suporte_binario <- terra::ifel(!is.na(ref_mask), 1, NA)
suporte_poligono <- terra::as.polygons(suporte_binario, aggregate = TRUE,
                                     values = FALSE, na.rm = TRUE)
if (nrow(suporte_poligono) == 0L) stop("Contorno raster vazio.")
suporte_sf <- sf::st_as_sf(suporte_poligono)
suporte_sf <- sf::st_sf(id = 1L, geometry = sf::st_union(suporte_sf))
if (!all(sf::st_is_valid(suporte_sf))) stop("Contorno raster invalido.")
geo_tmp <- tempfile(fileext = ".geojson")
# Coordenadas preservadas no CRS local, informado explicitamente ao GEE.
sf::st_write(suporte_sf, geo_tmp, quiet = TRUE, driver = "GeoJSON",
             delete_dsn = TRUE, layer_options = "RFC7946=NO")
geom <- jsonlite::fromJSON(geo_tmp, simplifyVector = FALSE)$features[[1]]$geometry
unlink(geo_tmp)
config <- list(asset = asset, crs = crs_gee, transform = unname(af),
               geometry = geom, excluded_cells = excluir,
               suporte = "Contorno das celulas validas do raster local de 1985")
rm(suporte_binario, suporte_poligono, suporte_sf)
gc(verbose = FALSE)

# Importacao e inicializacao independentes dos objetos antigos ee_py/integration.
if ("py_require" %in% getNamespaceExports("reticulate")) {
  reticulate::py_require("earthengine-api")
}
ee_etapa19 <- tryCatch(reticulate::import("ee", convert = TRUE), error = function(e) {
  stop("Nao foi possivel importar earthengine-api: ", conditionMessage(e),
       "\nConfigure o Python do reticulate ou instale earthengine-api nesse ambiente.")
})
inicializar <- function() {
  if (nzchar(projeto_gee)) ee_etapa19$Initialize(project = projeto_gee)
  else ee_etapa19$Initialize()
}
falha <- tryCatch({ inicializar(); NULL }, error = function(e) conditionMessage(e))
if (!is.null(falha)) {
  cat("\nEarth Engine nao inicializou:\n", falha, "\n")
  if (!interactive()) stop("Execute interativamente para configurar autenticacao/projeto.")
  if (!nzchar(projeto_gee)) {
    projeto_gee <- trimws(readline("ID do seu projeto Google Cloud com Earth Engine: "))
  }
  if (!nzchar(projeto_gee)) stop("Projeto nao informado. O ID nao e o seu email.")
  falha <- tryCatch({ inicializar(); NULL }, error = function(e) conditionMessage(e))
  if (!is.null(falha)) {
    cat("\nAutenticando sua conta pelo navegador.\n")
    ee_etapa19$Authenticate(auth_mode = "localhost")
    tryCatch(inicializar(), error = function(e) {
      stop("Inicializacao falhou: ", conditionMessage(e),
           "\nConfira o ID, acesso ao projeto e habilitacao da API Earth Engine.")
    })
  }
}
py_etapa19 <- reticulate::import_main(convert = TRUE)
py_etapa19$config_json <- as.character(
  jsonlite::toJSON(config, auto_unbox = TRUE, digits = 16)
)
reticulate::py_run_string("import ee, json\ncfg = json.loads(config_json)\nasset = cfg['asset']\nintegration = ee.Image(asset)\nbands = integration.bandNames().getInfo()\nmissing = [f'classification_{y}' for y in range(1985, 2025) if f'classification_{y}' not in bands]\nif missing:\n    raise RuntimeError('Bandas ausentes: ' + ', '.join(missing))\nroi = ee.Geometry(cfg['geometry'], proj=cfg['crs'], geodesic=False)\nproj = ee.Projection(cfg['crs'], cfg['transform'])\n# Valid pixel footprint already excludes the 19 NoData cells.\nsupport = ee.Image.constant(1).reproject(proj)\narea = ee.Image.pixelArea().divide(10000)\n\ndef image_year(year):\n    # Default categorical resampling is nearest neighbour. No smoothing.\n    img = integration.select(f'classification_{int(year)}').reproject(proj)\n    return img.updateMask(support).updateMask(img.gt(0)).rename('code')\n\ndef reduce_sum(image):\n    return image.reduceRegion(\n        reducer=ee.Reducer.sum().unweighted(), geometry=roi,\n        crs=cfg['crs'], crsTransform=cfg['transform'],\n        maxPixels=1e13, tileScale=4).getInfo()\n\ndef histogram(year):\n    out = image_year(year).reduceRegion(\n        reducer=ee.Reducer.frequencyHistogram().unweighted(), geometry=roi,\n        crs=cfg['crs'], crsTransform=cfg['transform'],\n        maxPixels=1e13, tileScale=4).getInfo()\n    return json.dumps(out.get('code', {}))\n\ndef sample_check(year, samples_json):\n    samples = json.loads(samples_json)\n    features = [ee.Feature(ee.Geometry.Point(s['xy'], proj=cfg['crs']),\n                   {'expected': s['expected'], 'id': s['id']}) for s in samples]\n    out = image_year(year).sampleRegions(\n        collection=ee.FeatureCollection(features), properties=['expected', 'id'],\n        projection=proj, tileScale=4, geometries=False).getInfo()\n    props = [f['properties'] for f in out['features']]\n    return json.dumps({'n_requested': len(samples), 'n_returned': len(props),\n                      'n_different': sum(int(p['expected']) != int(p['code']) for p in props)})\n\ndef transitions(year):\n    a, b = image_year(year), image_year(year + 1)\n    # Common valid support; missing classifications are not interpreted as losses.\n    valid = a.mask().And(b.mask())\n    wet0, wet1 = a.eq(11), b.eq(11)\n    agriculture = b.eq(20).Or(b.eq(21)).Or(b.eq(41))\n    masks = {\n        'common_valid': valid,\n        'wetland_initial': wet0,\n        'wetland_final': wet1,\n        'wetland_persistence': wet0.And(wet1),\n        'wetland_pasture': wet0.And(b.eq(15)),\n        'wetland_agriculture': wet0.And(agriculture),\n        'wetland_urban': wet0.And(b.eq(24)),\n        'wetland_water': wet0.And(b.eq(33)),\n        'wetland_aquaculture': wet0.And(b.eq(31)),\n        'wetland_plantation': wet0.And(b.eq(9)),\n        'wetland_loss_total': wet0.And(wet1.Not()),\n        'wetland_gain_total': wet0.Not().And(wet1),\n        'aquaculture_initial': a.eq(31),\n        'aquaculture_final': b.eq(31)\n    }\n    stack = None\n    for name, mask in masks.items():\n        mask = mask.And(valid)\n        ha = area.updateMask(mask).rename(name + '_ha')\n        count = ee.Image.constant(1).updateMask(mask).rename(name + '_cells')\n        pair = ha.addBands(count)\n        stack = pair if stack is None else stack.addBands(pair)\n    out = reduce_sum(stack)\n    return json.dumps({k: (0 if v is None else v) for k, v in out.items()})\n")

# Conferencia antes das 39 transicoes. Nao confundir area coincidente com
# equivalencia pixel a pixel: adicionamos amostras, mas nao um teste exaustivo.
comparacoes <- list()
amostras <- list()
for (ano in anos_locais) {
  cat("\nConferindo mapa local x GEE:", ano, "\n")
  r <- terra::rast(mapa(ano))
  if (!isTRUE(terra::compareGeom(ref, r, stopOnError = FALSE))) {
    stop("Grade diferente no mapa de ", ano)
  }
  r <- terra::mask(r, dentro)
  r <- terra::ifel(r == 0, NA, r)
  f <- terra::freq(r)
  local <- data.frame(codigo = as.integer(f$value), n_local = as.numeric(f$count))
  hh <- jsonlite::fromJSON(py_etapa19$histogram(as.integer(ano)))
  gee <- data.frame(codigo = as.integer(names(hh)), n_gee = as.numeric(unlist(hh)))
  cmp <- merge(local, gee, by = "codigo", all = TRUE)
  cmp$n_local[is.na(cmp$n_local)] <- 0
  cmp$n_gee[is.na(cmp$n_gee)] <- 0
  cmp$ano <- ano
  cmp$diferenca_celulas <- cmp$n_gee - cmp$n_local
  comparacoes[[as.character(ano)]] <- cmp
  set.seed(1900 + ano)
  p <- terra::spatSample(r, size = 2000, method = "random", na.rm = TRUE,
                       as.points = TRUE, values = TRUE)
  xy <- terra::crds(p)
  valores <- terra::values(p)[, 1]
  lista <- lapply(seq_along(valores), function(i) {
    list(xy = unname(xy[i, ]), expected = as.integer(valores[i]), id = as.integer(i))
  })
  s <- jsonlite::fromJSON(py_etapa19$sample_check(as.integer(ano),
                      jsonlite::toJSON(lista, auto_unbox = TRUE, digits = 16)))
  amostras[[as.character(ano)]] <- data.frame(ano = ano,
    n_solicitado = s$n_requested, n_retornado = s$n_returned,
    n_diferente = s$n_different)
  rm(r, p); gc(verbose = FALSE)
}
comparacoes <- do.call(rbind, comparacoes)
amostras <- do.call(rbind, amostras)
write.csv(comparacoes, file.path(pasta, "gee_local_class_checks.csv"),
          row.names = FALSE)
write.csv(amostras, file.path(pasta, "gee_local_sample_checks.csv"),
          row.names = FALSE)
print(amostras, row.names = FALSE)
# Criterio operacional de consistencia, nao prova de igualdade pixel a pixel.
# Mesma contagem total, amostras coincidentes e soma absoluta das diferencas
# de classes <= 0,001% das celulas. O limite e explicitamente documentado.
# Diferencas pequenas podem decorrer de reprojecao/categorizacao de bordas;
# a causa nao e demonstrada por esta conferencia agregada.
limite_fracao_L1 <- 1e-5
conferencia_resumo <- do.call(rbind, lapply(split(comparacoes, comparacoes$ano),
  function(z) data.frame(ano = z$ano[1], n_local = sum(z$n_local),
    n_gee = sum(z$n_gee), diferenca_total = sum(z$diferenca_celulas),
    soma_diferencas_absolutas = sum(abs(z$diferenca_celulas)),
    fracao_L1 = sum(abs(z$diferenca_celulas)) / sum(z$n_local))))
write.csv(conferencia_resumo,
          file.path(pasta, "gee_local_support_checks.csv"),
          row.names = FALSE)
print(conferencia_resumo, row.names = FALSE, digits = 8)
if (any(conferencia_resumo$diferenca_total != 0) ||
    any(conferencia_resumo$fracao_L1 > limite_fracao_L1) ||
    any(amostras$n_retornado != amostras$n_solicitado) ||
    any(amostras$n_diferente != 0)) {
  stop("Conferencia fora do criterio operacional. Diagnosticos salvos. ",
       "Nao recalculamos correlacoes; envie as tabelas de conferencia.")
}
cat("\nConferencia dentro do criterio operacional documentado.\n",
    "A serie anual permanece uma analise do produto GEE Collection 10.1.\n",
    "Nao ha comprovacao de identidade pixel a pixel com os mapas locais.\n")

# Transicoes anuais: 11 apenas; aquicultura/plantacao como destinos separados.
linhas <- list()
for (ano in 1985:2023) {
  cat("\nCalculando:", ano, "->", ano + 1, "\n")
  z <- jsonlite::fromJSON(py_etapa19$transitions(as.integer(ano)))
  if (z$common_valid_cells != n_ref) {
    stop("Suporte incompleto na transicao ", ano, "-", ano + 1,
         ": ", z$common_valid_cells, " celulas. Nao tratar NoData como perda.")
  }
  if (abs(z$common_valid_ha - area_ref) / area_ref > 0.001) {
    stop("Area GEE diverge mais de 0,1% da area local. Confira o calculo de area.")
  }
  v <- data.frame(ano_inicial = ano, ano_final = ano + 1,
    area_comum_ha = z$common_valid_ha, n_cells = z$common_valid_cells,
    wetland_inicial_ha = z$wetland_initial_ha,
    wetland_final_ha = z$wetland_final_ha,
    wetland_persistencia_ha = z$wetland_persistence_ha,
    wetland_pasture_ha = z$wetland_pasture_ha,
    wetland_agriculture_ha = z$wetland_agriculture_ha,
    wetland_urban_ha = z$wetland_urban_ha,
    wetland_water_ha = z$wetland_water_ha,
    wetland_aquaculture_ha = z$wetland_aquaculture_ha,
    wetland_plantation_ha = z$wetland_plantation_ha,
    wetland_loss_total_ha = z$wetland_loss_total_ha,
    wetland_gain_total_ha = z$wetland_gain_total_ha,
    aquaculture_inicial_ha = z$aquaculture_initial_ha,
    aquaculture_final_ha = z$aquaculture_final_ha)
  if (abs(v$wetland_inicial_ha - v$wetland_persistencia_ha -
          v$wetland_loss_total_ha) > 0.01 ||
      abs(v$wetland_final_ha - v$wetland_persistencia_ha -
          v$wetland_gain_total_ha) > 0.01) stop("Fechamento falhou em ", ano)
  # Mantem o indicador anterior (pasture + agriculture + urban) explicitamente.
  v$conversion_pasture_agriculture_urban_ha <-
    v$wetland_pasture_ha + v$wetland_agriculture_ha + v$wetland_urban_ha
  # Indicador ampliado separado; nao muda silenciosamente a definicao anterior.
  v$conversion_managed_including_aquaculture_plantation_ha <-
    v$conversion_pasture_agriculture_urban_ha + v$wetland_aquaculture_ha +
    v$wetland_plantation_ha
  for (campo in c("wetland_loss_total", "wetland_pasture", "wetland_agriculture",
                  "conversion_pasture_agriculture_urban",
                  "conversion_managed_including_aquaculture_plantation")) {
    v[[paste0(campo, "_pct")]] <- 100 * v[[paste0(campo, "_ha")]] / v$wetland_inicial_ha
  }
  linhas[[as.character(ano)]] <- v
  write.csv(do.call(rbind, linhas),
            file.path(pasta, "annual_wetland_transitions_partial.csv"),
            row.names = FALSE)
}
wet <- do.call(rbind, linhas)
write.csv(wet, file.path(pasta, "annual_wetland_transitions.csv"),
          row.names = FALSE)

# Ano hidrologico t = outubro de t-1 a setembro de t.
# Vinculo por rotulo anual; a data efetiva da mudanca no mapa anual e desconhecida.
# "Lag 1" usa t-1 por match, sem deslocar observacoes atraves de lacunas.
wet$AI_ano_inicial <- clima$AI[match(wet$ano_inicial, clima$ano_hid)]
wet$AI_ano_anterior <- clima$AI[match(wet$ano_inicial - 1L, clima$ano_hid)]
wet$precipitacao_mm <- clima$precipitacao_anual_mm[
  match(wet$ano_inicial, clima$ano_hid)]
wet$PET_mm <- clima$pet_mm[match(wet$ano_inicial, clima$ano_hid)]
write.csv(wet, file.path(pasta, "annual_wetland_climate.csv"),
          row.names = FALSE)

indicadores <- c("conversion_pasture_agriculture_urban_pct",
                 "wetland_pasture_pct", "wetland_agriculture_pct")
resultados <- list()
for (ai in c("AI_ano_inicial", "AI_ano_anterior")) {
  for (destino in indicadores) {
    ok <- is.finite(wet[[ai]]) & is.finite(wet[[destino]])
    xx <- wet[[ai]][ok]; yy <- wet[[destino]][ok]
    if (length(xx) < 3L || length(unique(xx)) < 2L || length(unique(yy)) < 2L) {
      rho <- p_nominal <- NA_real_
    } else {
      tt <- stats::cor.test(xx, yy, method = "spearman", exact = FALSE)
      rho <- unname(tt$estimate); p_nominal <- tt$p.value
    }
    resultados[[length(resultados) + 1L]] <- data.frame(
      AI_associado = ai, indicador = destino, n_pares = sum(ok),
      rho = rho, p_nominal = p_nominal)
  }
}
resultado <- do.call(rbind, resultados)
resultado$p_Holm_6_testes <- stats::p.adjust(resultado$p_nominal, method = "holm")
write.csv(resultado, file.path(pasta, "wetland_aridity_correlations.csv"),
          row.names = FALSE)
print(resultado, row.names = FALSE, digits = 6)
cat("\nP-valores nominais e Holm nao corrigem dependencia temporal.\n",
    "Correlacoes exploratorias; nao demonstram efeito causal do deficit hidrico.\n",
    "As datas anuais dos mapas nao identificam a data efetiva de cada conversao.\n")
metadados <- list(asset = asset, projeto = projeto_gee,
  bacia = arquivo_bacia, grade = config[c("crs", "transform", "excluded_cells", "suporte")],
  fonte_clima = arquivo_clima, wetland_natural_codigo = 11,
  aquicultura_codigo = 31, validacao = "Consistencia em nove anos; nao comprova identidade pixel a pixel",
  limite_fracao_L1_contagens = limite_fracao_L1,
  conferencia_resumo = conferencia_resumo,
  conferencia_amostras = amostras,
  area_local_ha = area_ref, area_GEE_ha = wet$area_comum_ha[1],
  rotulo_hidrologico = "ano t: outubro de t-1 a setembro de t",
  estatistica = "Spearman bilateral exploratorio; p nominal e Holm de seis testes",
  versao_R = R.version.string,
  pacotes_R = as.list(vapply(pacotes, function(p) as.character(utils::packageVersion(p)),
                           character(1))),
  versao_earthengine_api = ee_etapa19$`__version__`)
jsonlite::write_json(metadados, file.path(pasta, "etapa19_metadados_AUDITADOS.json"),
                     auto_unbox = TRUE, pretty = TRUE, digits = 16)
capture.output(sessionInfo(), file = file.path(pasta, "etapa19_sessionInfo.txt"))
cat("\nConcluido. Novos arquivos salvos em:", pasta, "\n")
