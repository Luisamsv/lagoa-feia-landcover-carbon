# OLS class-area extrapolation recovered from etapa16.R (16C).
# Fixed effective densities from original-code accounting in 2024.
# No clipping, normalization, confidence intervals or spatial allocation.
run_projections <- function(cfg,classes_data,series) {
  classes <- unique(classes_data$classe_estudo)
  den <- classes_data[classes_data$ano==2024,]
  den$densidade_efetiva_Mg_ha <- den$carbono_total_Tg*1e6/den$area_ha
  if(nrow(den)!=8L || anyDuplicated(den$classe_estudo) || any(den$area_ha<=0))
    stop('Invalid 2024 effective densities.')
  years <- c(2030,2050,2070);windows <- c(1985,2000,2010)
  forecasts <- list();models <- list();k <- 0L
  for(start in windows) for(cl in classes) {
    d <- classes_data[classes_data$classe_estudo==cl & classes_data$ano>=start,]
    fit <- lm(area_ha~ano,data=d);sm <- summary(fit)
    pred <- as.numeric(predict(fit,newdata=data.frame(ano=years)))
    if(any(!is.finite(pred)) || any(pred<0))
      stop('Negative/non-finite projection. Do not clip or normalize silently.')
    density <- den$densidade_efetiva_Mg_ha[match(cl,den$classe_estudo)]
    k <- k+1L
    forecasts[[k]] <- data.frame(janela=paste0(start,'-2024'),classe=cl,
      ano=years,area_ha=pred,densidade_efetiva_Mg_ha=density,estoque_Tg=pred*density/1e6)
    models[[k]] <- data.frame(janela=paste0(start,'-2024'),classe=cl,n=nrow(d),
      intercept=unname(coef(fit)[1]),slope_ha_ano=unname(coef(fit)[2]),
      R2=sm$r.squared,p=sm$coefficients[2,4])
  }
  long <- do.call(rbind,forecasts)
  closure <- aggregate(area_ha~janela+ano,long,sum)
  if(any(abs(closure$area_ha-cfg$area_esperada)>.1)) stop('Projected area does not close.')
  total <- aggregate(estoque_Tg~janela+ano,long,sum)
  baseline <- series$carbono_total_Tg[series$ano==2024]
  total$delta_2024_Tg <- total$estoque_Tg-baseline
  total$delta_2024_pct <- 100*total$delta_2024_Tg/baseline
  envelope <- do.call(rbind,lapply(years,function(y) {
    z <- total[total$ano==y,]
    data.frame(ano=y,minimo_Tg=min(z$estoque_Tg),maximo_Tg=max(z$estoque_Tg),
      central_Tg=z$estoque_Tg[z$janela=='1985-2024'])
  }))
  salvar(long,'carbon_projection_by_class_window.csv',cfg)
  salvar(total,'carbon_projection_totals.csv',cfg)
  salvar(envelope,'carbon_projection_envelope.csv',cfg)
  salvar(do.call(rbind,models),'landcover_ols_models.csv',cfg)
  salvar(closure,'projection_area_checks.csv',cfg)
  ref <- ler(file.path(cfg$referencia,'carbon_projection_reference.csv'))
  norm <- function(x)tolower(gsub('[^A-Za-z]','',x))
  ref$key <- paste(ref$janela,ref$ano,norm(ref$classe))
  long$key <- paste(long$janela,long$ano,norm(long$classe))
  j <- match(long$key,ref$key)
  if(anyNA(j)||anyDuplicated(ref$key)||nrow(ref)!=nrow(long)) stop('Projection reference keys differ.')
  check <- data.frame(key=long$key,area_difference_ha=long$area_ha-ref$area_ha[j],
                       stock_difference_Tg=long$estoque_Tg-ref$estoque_Tg[j])
  salvar(check,'projection_reference_check.csv',cfg)
  if(any(abs(check$area_difference_ha)>.001)||any(abs(check$stock_difference_Tg)>1e-5))
    stop('Projection differs from deposited reference. Inspect projection_reference_check.csv.')
  invisible(list(long=long,total=total,envelope=envelope))
}
