# Missing inputs and execution status

## Still needed for the remaining manuscript analyses

1. The populated CMIP6 basin results table originally named `CMIP6_precipitacao_bacia_FINAL_etapa15B.csv`, plus exact source identification/retrieval instructions for the monthly MRI-ESM2-0 rasters. Original scripts referenced `D:/climatico/cmip6/climate/wc2.1_2.5m` on the author's computer; that path is not a runtime dependency of this package.
2. The actual ONI series used. The previous `oni.csv` upload contained headers only. A new current download could differ from the archived series and has not been substituted silently.
3. Underlying station/PET processing inputs or exact public retrieval instructions for reproducing the audited hydrological climate table from source observations. The populated processed table is included.
4. Annual natural-wetland transition outputs, if readers should be able to inspect them without running the authenticated Earth Engine stage. The code is included, but those outputs were not supplied.
5. Final manuscript figure scripts and source requirements if full figure reproduction is intended. The integrated workflow does not automatically render manuscript figures.

## What has been recovered

The original complete carbon parameters for 15 MapBiomas codes are included in `data/reference/carbon_parameters.csv`; no transcription from rounded manuscript values is required. The populated historical area/transition tables and the 40-year processed hydrological climate series are included. Three years (2012, 2014, 2023) are incomplete; the other 37 are used in complete-year analyses.

The 2020–2024 descriptive window in Figure 5 has four complete years and mean precipitation 915.975 mm. The corresponding Table 2 interval excludes the terminal year and uses 2020–2022. The previously deleted manuscript sentence has not been reinserted.

## Publication instructions

Extract the package and upload its CONTENTS at the repository root, retaining the folders. Keep the separately uploaded `Rasters.zip` and `watershed.zip`. Use the new README and RUN_ALL.R. Historical script copies and the provisional `00_base_historical.R` are not needed in this publication layout. Existing duplicate files in GitHub are not deleted by uploading this package.

Numerical checks of the deposited CSVs passed, but the integrated R workflow has not been run in the preparation environment. Do not describe the repository as fully validated from raw data to all manuscript figures until that workflow and the remaining inputs have been checked.
