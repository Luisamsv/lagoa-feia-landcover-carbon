# Scope of remaining source-data reconstruction and validation

## Resolved inputs

- Original full-precision carbon parameters for 15 MapBiomas codes.
- Historical original-code areas and transitions, carbon reference series, and 40-year processed hydrological climate table.
- NOAA CPC ERSSTv5 seasonal ONI, newly retrieved on 2026-10-19. All 25 reconstructed ENSO episodes match the supplied supplementary Table S1. This is documented as a new retrieval, not the lost original download.
- Populated MRI-ESM2-0 CMIP6 basin precipitation for 12 SSP/period combinations. AUDITADA and FINAL have identical precipitation; period summaries agree. Old difference columns used incompatible reference means and were replaced by descriptive contrasts against 898.0918919 mm. See cmip6_provenance.json.

## Outside the integrated numerical run

1. Raw WorldClim monthly raster extraction: the supplied original scripts referenced D:/climatico/cmip6/climate/wc2.1_2.5m on the author's computer. Exact source-raster access information is needed for raw-to-basin reproduction. The populated extracted basin values are included and support the numerical context module.
2. Original station/PET preprocessing: the populated processed hydrological series is included; original source files or exact retrieval instructions are needed to reconstruct it from observations.
3. Annual wetland transition outputs: the recovered Earth Engine module requires spatial inputs, remote access and an authorized project. Its annual output tables were not supplied; the code is optional.
4. Final manuscript figures: this numerical workflow does not automatically render every final panel. Figure 1 is prepared in QGIS.

## Validation status

Independent checks of the supplied numerical tables passed. R/terra, the spatial archives and an authorized Earth Engine session were unavailable in the preparation environment. The integrated R workflow and optional spatial/Monte Carlo/remote stages have not been executed there. Do not describe it as fully validated from all raw data to every manuscript figure.

## Upload instructions

Extract the package and upload its CONTENTS at the repository root, retaining scripts/, data/ and metadata/. Keep the separately uploaded Rasters.zip and watershed.zip. Use this updated README and RUN_ALL.R. Old archive folders, the provisional 00_base_historical.R and the earlier extensionless Data ZIP are not needed in this publication layout; uploading this package does not delete old GitHub files.
